if (!localStorage.getItem("adminLogin")) {
    window.location.href = "error.html";
}
